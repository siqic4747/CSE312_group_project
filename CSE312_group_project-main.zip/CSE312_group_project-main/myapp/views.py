from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from . import logic


def index(request):
    # Your index view logic here
    response = logic.index_logic(request)
    return response

def login(request):
    response = logic.login_logic(request)
    return response

def register(request):
    response = logic.register_logic(request)
    return response

def register_form(request): 
    response = logic.register_form_logic(request)
    return response

def forgot_password_request(request):
    response = logic.forgot_password_request_logic(request)
    return response

def myStudygroupsempty(request):
    response = logic.myStudygroupsempty_logic(request)
    return response

def studyGroups(request):
    response = logic.studyGroups_logic(request)
    return response

def verifyEmail(request):
    response = logic.verifyEmail_logic(request)
    return response

def homePage(request):
    response = logic.homePage_logic(request)
    return response

def createStudygroups(request):
    response = logic.createStudygroups_logic(request)
    print("THIS IS RESPONSE OF create study group",response)
    return response

def createAccount(request):
    response = logic.createAccount_logic(request)
    
    return response

def changePassword(request):
    response = logic.changePassword_logic(request)
    return response

def accountProfile(request):
    response = logic.accountProfile_logic(request)
    return response

def threeclass_StudyGroups(request):
    response = logic.threeclass_StudyGroups(request)
    return response

