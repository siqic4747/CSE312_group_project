from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.shortcuts import get_object_or_404

#This should be the logic that handles everything to make the views code more readable

def index_logic(request):
    return render(request, 'index.html')

def login_logic(request):
    # login occurs when fourm post is pressed , index->login
    print("Request = " , request)
    username = request.POST.get('username')
    password = request.POST.get('password')
    print(username,password)
    #CHECK IF USERNAME AND PASSWORD AND CREATE SESSION HASH AND CREATE XRSF TOKEN
    #IF EVERYTHING CHECKS OUT THEN GO TO STUDYGROUPS ELSE GO BACK TO INDEX
    if (username == "dog"):
        return redirect('homePage')
    return redirect('index')

def register_logic(request):
    # Your register view logic here index->register
    print("Request = " , request)
    return render(request, 'register.html')

def register_form_logic(request):
    if request.method == 'POST':
        # Retrieve the values from the form
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        retype_password = request.POST.get('retype_password')
    if (retype_password != password):
        print("passed")
        return redirect('register')
        pass
        #ADD LOGIC TO HANDLE IF PASSWORD IS WRONG 
        
    # if (there is something)
    #CHECK IF USERNAME AND EMAIL HAS ALREADY BEEN USED 
    
        
    # Add logic to handle the form data here SHOULD SAVE ALL TO DATABASE

    # Redirect back to the 'register' URL
    

# Render the registration form template if the request method is GET
    return redirect('index')

def forgot_password_request_logic(request):
    # Your forgot password request view logic here
    print("Request = " , request)
    return render(request, 'forgot-password.html')

def myStudygroupsempty_logic(request):
    print("Request = " , request)
    return render(request, 'myStudygroupsempty.html')
#############

def studyGroups_logic(request):
    print("Request = " , request)
    return render(request, 'studyGroups.html')

def verifyEmail_logic(request):
    print("Request = " , request)
    return render(request, 'verifyEmail.html')

def homePage_logic(request):
    print("Request = " , request)
    return render(request, 'homePage.html')

def createStudygroups_logic(request):
    print("Request = " , request)

    return render(request, 'createStudygroups.html')

def createAccount_logic(request):
    print("Request = " , request)
    return render(request, 'createAccount.html')

def changePassword_logic(request):
    print("Request = " , request)
    return render(request, 'changePassword.html')

def accountProfile_logic(request):
    print("Request = " , request)
    return render(request, 'accountProfile.html')


def threeclass_StudyGroups(request):
    return render(request, '312StudyGroups.html')