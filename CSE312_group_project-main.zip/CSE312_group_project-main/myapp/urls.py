from django.urls import path
from django.urls import include
from . import views

urlpatterns = [
    
    path('', views.index, name='index'), #Login
    path('login/', views.login, name= 'login'),#Login fourm when login is pressed
    path('register/', views.register, name='register'), #register
    path('register-form/', views.register_form, name= 'register_form'), #Occurs once the register fourm is pressed
    path('forgot-password-request/', views.forgot_password_request, name='forgot_password_request'), #Occurs when forgot password is pressed
    path('homePage/myStudygroupsempty/', views.myStudygroupsempty, name= 'myStudygroupsempty'),
    path('homePage/studyGroups/', views.studyGroups, name='studyGroups'),
    path('homePage/verifyEmail/', views.verifyEmail, name= 'verifyEmail'),
    path('homePage/', views.homePage, name= 'homePage'),
    path('homePage/createStudygroups/', views.createStudygroups, name= 'createStudygroups'),    
    path('homePage/createAccount/', views.createAccount, name= 'createAccount'),
    path('homePage/changePassword/', views.changePassword, name= 'changePassword'),
    path('homePage/accountProfile/', views.accountProfile, name= 'accountProfile'),
    path('homePage/312StudyGroups/', views.threeclass_StudyGroups, name= '312StudyGroups'),
    
]
